/*
	This is the Haptic Cue Detection Node.

	The processes subscribes to hc_dorce_topic were the cartesian force norm |F| is streamed.
	
	Then, it executes 
	
	-Savvas
*/

#include "ros/ros.h"

#include <string>
#include <std_msgs/Float64.h>

#include <std_msgs/Bool.h>

#include "HapticCues.h"


HapticCues* hapticCues; 
ros::Publisher pub;

void f_sample_callback(const std_msgs::Float64::ConstPtr& msg){

	float sample = msg->data;
	
	int temp = hapticCues->hapticDetection(sample);
	std_msgs::Bool HC_msg;

	if (temp == 1)
	{
		ROS_INFO("[HC_NODE]:\tHaptic Detected");
		HC_msg.data = true;
	}else
		HC_msg.data = false;

		pub.publish(HC_msg);
}


int main(int argc, char** argv){

	ros::init(argc, argv, "hc_node");
	ros::NodeHandle n;

	hapticCues = new HapticCues();

	pub = n.advertise<std_msgs::Bool>("prog_automation_node/hc_detection_topic", 1000);
	ros::Subscriber sub = n.subscribe("prog_automation_node/hc_force_topic", 1000, f_sample_callback);

	ROS_INFO("[HC_NODE]: Haptic Cues Detection Node is up and Running");

	ros::spin();

	return 0;
}

