#include <vector>
#include <armadillo>
#include <HCSegmentator.h>

// TODO:
// Compare segmentator and matlab code - Something is different (detector seems ok)
//
// Return Codes (length=1):
//  100: Fit step not full
//  101: Model is fitting
//  102: Added new segment to group
//  103: Previous segment was of size 1

HCSegmentator::HCSegmentator() {
	/* Assign values from config file */
	fit_step = 30;
	poly_order = 1;
	max_fit_error = 0.055;
	group_distance = 5*fit_step;
  comparison_slack = 4*fit_step;
	segment_size_limit = 800;
	fit_start = 0;
	fit_end = 0;
	current_sample = 0;
	fitCounter = 0;

	/* Set first segment at t=0 */
	previous_segment.push_back(0);
}


HCSegmentator::~HCSegmentator() {}

/* Adds samples to local buffer */
arma::vec HCSegmentator::addSample(float sample) {
	/* Add sample to buffer */
	signal_buffer.push_back(sample);

	/* Every fit_step samples fit polynomial model
	 * to signal segment */
	fitCounter++;
	if (fitCounter == fit_step) {	
		current_sample += fit_step;
		fitCounter = 0;
		return fitModel();
	}

  arma::vec tempRetVec;
  tempRetVec << 100;
  return tempRetVec;
}


/* Fits polynomial model to segment data and
 * calculates MAE (mean absolute error) of fit */
arma::vec HCSegmentator::fitModel() {
	/* Extract signal from buffer and save in vector */
	arma::vec curr_window_signal(current_sample - fit_start);
	for (int i=fit_start; i<current_sample; i++) {
		curr_window_signal(i-fit_start) = signal_buffer[i];
	}

	/* Fit polynomial to data 
	 * and calculate mean absolute error (MAE) */
	arma::vec x = arma::linspace<arma::vec>(fit_start, current_sample-1, current_sample - fit_start); 
	arma::vec coeffs = arma::polyfit(x, curr_window_signal, poly_order);
	arma::vec poly_values = arma::polyval(coeffs, x);
	float mae = mean(abs(poly_values - curr_window_signal));

	/* If MAE is above the threshold or segment size limit is reached
	 * create a new segment */
	if (mae > max_fit_error || (current_sample - previous_segment.back() > segment_size_limit)) {
		fit_end = std::max(current_sample-fit_step-1, 0);
		fit_start = fit_end+1;

		/* Cluster new segment */
		return clusterSegment(fit_end);
	}

  arma::vec tempRetVec;
  tempRetVec << 101;
  return tempRetVec;
}


/* Cluster neighboring segments into one */
arma::vec HCSegmentator::clusterSegment(int fit_end) {
	/* Check if new segment clusters with previous ones */
	if (fit_end - previous_segment.back() < group_distance) {
		previous_segment.push_back(fit_end);
	} else {
		arma::vec segment_signal;
    segment_signal << 103;

		/* Extract signal from previous segment 
		 * (if existant) */
		if (previous_segment.size() > 1) {
			/* Get segment samples and pass them for
			 * cue detection */
			int start = previous_segment.front();
			int end = previous_segment.back();
      
      start -= comparison_slack;
      end += comparison_slack;

			segment_signal = arma::zeros<arma::vec>(end-start+1);
			for (int i=start; i<=end; i++) {
				segment_signal(i-start) = signal_buffer[i];
			}
		}

		/* Delete unneeded samples and rearrange counters */
		std::vector<float>::iterator start = signal_buffer.begin();
		std::vector<float>::iterator end = signal_buffer.end();
		end -= fit_step+1+comparison_slack;
		signal_buffer.erase(start,end);
    
		current_sample = fit_step+1+comparison_slack;
		fit_end = comparison_slack;
		fit_start = comparison_slack;

		/* Clear previous segment and start new */
		previous_segment.clear();
		previous_segment.push_back(fit_end);

		return segment_signal;
	}

  arma::vec tempRetVec;
  tempRetVec << 102;
  return tempRetVec;
}

