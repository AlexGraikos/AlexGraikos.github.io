#include <iostream>
#include <fstream>
#include <string>
#include <armadillo>
#include <HCSegmentator.h>
#include <HCDetector.h>

#include "ros/ros.h"
#include <ros/package.h>

/* TODO: Implement smoothing filter at input (not necessary)
 *       Read parameters from config file */

int main(int argc, char **argv) {
	
  ros::init(argc, argv, "hc_demo_node");
  ros::NodeHandle n;

	HCSegmentator segmentObject;
  HCDetector detectObject;

  /* Read samples from data file and pass to 
   * segmentator object */  
  std::string path = ros::package::getPath("haptic_cues");
  std::string simFile = "/hc_data/f1200.dat";
  std::fstream dataFile( (path+simFile).c_str() ,std::ios_base::in);
  
  float sample;
  int index = 0;
  while (dataFile >> sample) {
    index++;
    arma::vec x = segmentObject.addSample(sample);
    
   // std::cout << index<<" "<< sample<<std::endl;

    if (!x.is_empty()) {
      //std::cout << "Signal" << x << std::endl;
      //std::cout << "Testing cue at " << index << std::endl;
      if (detectObject.detectCue(x)) {
        std::cout << "Detected cue at " << index << "!" << std::endl;
      }
    }
  }
  dataFile.close();
  
  /*
  const char *x1_data = "0.5377 1.8339 -2.2588 0.8622 0.3188 "
   "-1.3077 -0.4336 0.3426 3.5784 2.7694 -1.3499 3.0349 0.7254 -0.0631 "
    "0.7147 -0.2050 -0.1241 1.4897 1.4090 1.4172 0.6715 -1.2075 0.7172 1.6302 0.4889 "
     "1.0347 0.7269 -0.3034 0.2939 -0.7873 0.8884 -1.1471 -1.0689 -0.8095 -2.9443 1.4384 0.3252 "
      "-0.7549 1.3703 -1.7115 -0.1022 -0.2414 0.3192 0.3129 -0.8649 -0.0301 -0.1649 0.6277 1.0933 1.1093";

  const char *x2_data = "-0.8637 0.0774 -1.2141 -1.1135 -0.0068 1.5326 -0.7697 0.3714 -0.2256 1.1174 -1.0891 "
    "0.0326 0.5525 1.1006 1.5442 0.0859 -1.4916 -0.7423 -1.0616 2.3505 -0.6156 0.7481 -0.1924 0.8886 -0.7648 -1.4023 "
     "-1.4224 0.4882 -0.1774 -0.1961 1.4193 0.2916 0.1978 1.5877 -0.8045 0.6966 0.8351 -0.2437 0.2157 -1.1658 ";
     //"-1.1480 0.1049 0.7223 2.5855 -0.6669 0.1873 -0.0825 -1.9330 -0.4390 -1.7947";

  arma::vec x1(x1_data);
  arma::vec x2(x2_data);

  //x1 = x1(arma::span(0,8));
  //x2 = x2(arma::span(0,11));

  std::cout << "x1\n" << x1 << std::endl;
  std::cout << "x2\n" << x2 << std::endl;

  //arma::mat dtwResult = detectObject.dtw(x1,x2,3);
  //std::cout << "Results\n" << dtwResult.col(0) << "\n" << dtwResult.col(1) << std::endl;

  //arma::vec x1_norm = detectObject.normalize(x1);
  //std::cout << "x1\n" << x1 << std::endl;
  //std::cout << "x1 normalized\n" << x1_norm << std::endl;
  
  //std::cout << "x1\n" << x1 << std::endl;
  //arma::vec x1_inerp = detectObject.interpolateBase(x1, 38);
  //std::cout << "x1 interp\n" << x1_inerp << std::endl;

  //std::cout << "x1\n" << x1 << std::endl;
  //arma::vec x1_paa = detectObject.paa(x1, 26);
  //std::cout << "x1_paa\n" << x1_paa << std::endl;

  //arma::vec q_levels = detectObject.generate_sax_levels(9,-10,10,10000,0,0.8);
  //std::cout << "q_levels\n" << q_levels << std::endl;
  //std::cout << "x1\n" << x1 << std::endl;
  //std::string symbols = detectObject.sax(x1,q_levels); 
  //std::cout << "SAX symbols " << symbols << std::endl;
  
  //std::cout << "x1\n" << x1 << std::endl;
  //std::cout << "x2\n" << x2 << std::endl;
  
  //arma::vec q_levels = detectObject.generate_sax_levels(9,-10,10,10000,0,0.8);
  //arma::mat dist_mat = detectObject.create_sax_distance_mat(q_levels);
  //std::cout << "q_levels\n" << q_levels << std::endl;
  //std::cout << "Distance matrix\n" << dist_mat << std::endl;

  //std::string symbols1 = detectObject.sax(x1,q_levels); 
  //std::string symbols2 = detectObject.sax(x2,q_levels); 

  //std::cout << "SAX Distance " << detectObject.sax_distance(dist_mat, symbols1, symbols2, x1.n_rows) << std::endl;

  detectObject.detectCue(x1);
  */

  return 1;
}
