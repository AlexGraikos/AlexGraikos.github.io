#include "HapticCues.h"
#include <armadillo>

HapticCues::HapticCues(){
	segmentObject = new HCSegmentator();
	detectObject = new HCDetector();
}

HapticCues::~HapticCues(){
	delete segmentObject;
	delete detectObject;
}

int HapticCues::hapticDetection(float F_sample){
	int hc_detected = 0;
  
  /* Send sample to segmentator */
	arma::vec x = segmentObject->addSample(F_sample);

	if (x.n_rows > 1) {
    /* If x has segment to detect cue send to detector */
    hc_detected = detectObject->detectCue(x);
    return hc_detected;
  } else if (x.n_rows) {
    /* Return ret. code */
    return x(0);
  }
}
