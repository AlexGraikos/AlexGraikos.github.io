#include <HCDetector.h>
#include <armadillo>
#include <iostream>
#include <string>
#include <vector>

#include <ros/package.h>

/* TODO: Check if shorter pulses give lesser SAX distances
 * If that is the case, adjust thresholds
 * Check classification algorithm / Tune */

HCDetector::HCDetector() {

  /* Setup detection parameters */
  q_levels = generate_sax_levels(9,-10,10,1000,0,0.8);
  sax_distance_mat = create_sax_distance_mat(q_levels);
  paa_cuts = 50; 
  dtw_delay_amount = 2.f;
  sax_distance_decision = 10.91;
  std_decision = 0.2; 
  skewness_decision = 0.2;

  /* Read knowledge base signals */

  this->DATA_DIR = ros::package::getPath("haptic_cues") + "/hc_data";
  int knowledgeBase_size = 5;
  float sample;
  char currKnowledgeSignal[3];
  for (int i=1; i<=knowledgeBase_size; i++) {
    sprintf(currKnowledgeSignal, "%d", i);
    std::string fileName = std::string(DATA_DIR+"/b") + std::string(currKnowledgeSignal) + std::string(".dat");
    std::fstream kbFile(fileName.c_str(), std::ios_base::in);

    /* Save temporarily to vector */
    std::vector<double> base;
    while (kbFile >> sample) {
      base.push_back(sample);
    }
    kbFile.close();

    /* Create arma::vec from std::vector and
     * pass to knowledgeBase */
    arma::vec b(base);
    knowledgeBase.push_back(normalize(arma::sqrt(b)));
  }
}

HCDetector::~HCDetector() {}

int HCDetector::detectCue(arma::vec signal) {
  int n = signal.n_rows;
  /* Normalize (and get square root of) signal */
  arma::vec normalized_signal = normalize(signal);

  /* Setup max DTW delay */
  int dtw_max_delay = std::max((int)(n*dtw_delay_amount),1);

  /* Compare with base signals */
  float avg_sax_distance = 0;
  for (int i=0; i<knowledgeBase.size(); i++) {
    arma::vec baseSignal = knowledgeBase[i];

    /* DTW */
    arma::mat dtwResult = dtw(baseSignal, normalized_signal, dtw_max_delay);

    /* PAA */
    arma::vec paa_base = paa(dtwResult.col(0));
    arma::vec paa_signal = paa(dtwResult.col(1));

    /* Generate SAX symbols */
    std::string symbols_base = sax(paa_base, q_levels);
    std::string symbols_signal = sax(paa_signal, q_levels);

    /* Calculate SAX distance */
    avg_sax_distance += sax_distance(sax_distance_mat, symbols_base, symbols_signal, dtwResult.n_rows); 
  }
  avg_sax_distance /= knowledgeBase.size();

  /* Create feature vector by adding std and skewness */
  float signal_std = arma::stddev(signal);
  float signal_skewness = 1.f/n * arma::sum(arma::pow(signal - arma::mean(signal),3)) 
      / pow((sqrt(1.f/n * arma::sum(arma::pow(signal - arma::mean(signal),2)))),3);

  arma::vec featureVector;
  featureVector << avg_sax_distance << signal_std << signal_skewness;

  std::cout << "Feature vector: " << featureVector.t();

  /* Classify feature vector */
  return classify(featureVector);
}
 
/* Z-normalization of input vector */
arma::vec HCDetector::normalize(arma::vec signal) {
  return (signal - arma::mean(signal)) / arma::stddev(signal);
}

/* Can be removed */
arma::vec HCDetector::interpolateBase(arma::vec base_signal, int force_signal_size) {
  /* Interpolate base signal values to match the size 
   * of the force signal */
  arma::vec x_base = arma::linspace(1, base_signal.n_rows, base_signal.n_rows);
  arma::vec x_interp = arma::linspace(1, base_signal.n_rows, force_signal_size);
  arma::vec base_signal_interp;
  interp1(x_base, base_signal, x_interp, base_signal_interp);

  return base_signal_interp;
}

/* Returns k x 2 matrix that contains the dtw distorted signals
 * in each column */
arma::mat HCDetector::dtw(arma::vec base, arma::vec signal, int max_delay) {
  /* Initialize DTW DP matrix and distance matrix */
  int m = base.n_rows;
  int n = signal.n_rows;

  arma::mat dtwMatrix = arma::ones(m,n)*arma::datum::inf;
  arma::mat distMat = arma::square(repmat(base,1,n) - repmat(signal.t(),m,1));

  /* Fill borders of matrix */
  dtwMatrix(0,0) = distMat(0,0);
  for (int i=1; i<std::min(m,max_delay+1); i++) { 
    dtwMatrix(i,0) = dtwMatrix(i-1,0) + distMat(i,0);
  }

  for (int i=1; i<std::min(n,max_delay+1); i++) {
    dtwMatrix(0,i) = dtwMatrix(0,i-1) + distMat(0,i);
  }

  /* Fill main part */
  for (int i=1; i<m; i++) {
    for (int j=std::max(1,i-max_delay); j<std::min(n,i+max_delay+1); j++) {
      float min = std::min(dtwMatrix(i-1,j), std::min(dtwMatrix(i,j-1), dtwMatrix(i-1,j-1)));
      dtwMatrix(i,j) = min + distMat(i,j);
    }
  }

  /* Backtrack DTW matrix to create distorted signals */
  arma::Col<int> next(2);
  next(0) = m-1;
  next(1) = n-1;
  std::vector<arma::Col<int> > sequence;
  sequence.push_back(next);
  float error_sum = 0;

  while(1) {
    if(next(0) <= 0 && next(1) <= 0) {
      error_sum += dtwMatrix(0,0);
      break;
    } else if (next(0) <= 0) {
      next(1) -= 1;
    } else if (next(1) <= 0) {
      next(0) -= 1;
    } else {
      double min_val = std::min(dtwMatrix(next(0)-1,next(1)), std::min(dtwMatrix(next(0),next(1)-1),
            dtwMatrix(next(0)-1,next(1)-1)));
      
      /* Must resolve issue when there are >1 min values before using 
      int min_index = 1*(min_val == dtwMatrix(next(0)-1,next(1))) + 2*(min_val == dtwMatrix(next(0),next(1)-1))
          + 3*(min_val == dtwMatrix(next(0)-1,next(1)-1));
      */
      
      int min_index;
      if (min_val == dtwMatrix(next(0)-1,next(1))) {
        min_index = 1;
      } else if (min_val == dtwMatrix(next(0),next(1)-1)) {
        min_index = 2;
      } else {
        min_index = 3;
      }

      switch (min_index) {
        case 1:
          next(0) -= 1;
          break;
        case 2:
          next(1) -= 1;
          break;
        case 3:
          next(0) -= 1;
          next(1) -= 1;
          break;
        default:
          std::cerr << "ERROR WHILE FINDING MIN VALUE IN DTW" << std::endl;
          std::cerr << "min_val = " << min_val << " min_index = " << min_index << std::endl;
      }
    }

    sequence.push_back(next);
    error_sum += dtwMatrix(next(0),next(1));
  }

  /* Resample original signals to create result */
  int new_size = sequence.size();
  arma::mat dtwSignals(new_size,2);

  for (int i=0; i<new_size; i++) {
    dtwSignals(new_size-(i+1),0) = base(sequence[i](0));
    dtwSignals(new_size-(i+1),1) = signal(sequence[i](1));
  }

  return dtwSignals;
}

arma::vec HCDetector::paa(arma::vec x) {
  int n = x.n_rows;
  /* Calculate PAA window length */
  int win_len = n/paa_cuts;
  arma::vec paa_x(paa_cuts);

  /* Generate PAA representation for each window */
  for (int i=0; i<paa_cuts-1; i++) {
    paa_x(i) = arma::sum(x(arma::span(i*win_len,(i+1)*win_len-1))) / (float)win_len;  
  }
  /* Generate PAA representation for final window (samples until the end) */
  arma::vec final_win_samples = x(arma::span((paa_cuts-1)*win_len, n-1));
  paa_x(paa_cuts-1) = arma::sum(final_win_samples) / (float)final_win_samples.n_rows;  

  return paa_x; 
}

std::string HCDetector::sax(arma::vec paa_x, arma::vec q_levels) {
  /* Create symbol string */
  int n = paa_x.n_rows;
  const char* alphabet = "abcdefghijklmnopqrstuvwxyz";
  std::string symbols(n,'\0');

  /* Assign symbols to PAA vector */
  for (int i=0; i<n; i++) {
    /* Search for first level greater than PAA value */
    for (int j=0; j<q_levels.n_rows; j++) {
      if (paa_x(i) < q_levels(j)) {
        symbols[i] = alphabet[j];
        break;
      }
    }
  }

  return symbols;
}

arma::vec HCDetector::generate_sax_levels(int n_levels, int start, int finish, int points, float mu, float sigma) {
  /* normpdf does not work on armadillo version < 8.3 */
  // /* Initialize level generation parameters */
  // float prob = 1.f / n_levels;
  // arma::vec x = arma::linspace(start,finish,points);

  // /* Create cdf values vectors */
  // /* C++11 Implementation */
  // //arma::vec cdf_val_old = arma::normcdf(x,mu,sigma);
  
  // /* C++98 Implementation */
  // /* Integrate pdf of desired points */
  // int left_end = (int)(mu - 10*sigma);
  // arma::vec cdf_val(x.n_rows);
  // arma::mat temp_mat;
  // for (int i=0; i<x.n_rows; i++) {
  //   if (i == 0) {
  //     arma::vec left_to_x = arma::linspace(left_end, x(i), points);
  //     arma::vec pdf_left_to_x = arma::normpdf(left_to_x, mu, sigma);
    
  //     temp_mat = arma::trapz(left_to_x, pdf_left_to_x);
  //     cdf_val(i) = temp_mat(0,0);
  //   } else {
  //     arma::vec left_to_x = arma::linspace(x(i-1), x(i), points);
  //     arma::vec pdf_left_to_x = arma::normpdf(left_to_x, mu, sigma);
    
  //     temp_mat = arma::trapz(left_to_x, pdf_left_to_x);
  //     cdf_val(i) = temp_mat(0,0) + cdf_val(i-1);
  //   }
  // }

  // int i = 0;
  // int level = 0;
  // float cum_sum = prob;
  // float epsilon = 0.05;
  // arma::vec q_levels(n_levels);

  // /* Scan through cdf values and create 
  //  * equal probability intervals */
  // while(1) {
  //   /* Break if all values are checked */
  //   if (i == cdf_val.n_rows || (cum_sum > n_levels*prob - epsilon)) {
  //     break;
  //   }

  //   /* Continue scanning or add value if probability is reached */
  //   if (cdf_val(i) < cum_sum) {
  //     i++;
  //   } else {
  //     cum_sum += prob;
  //     q_levels(level) = start + (i + 0.5)*(float)(finish-start)/points;
  //     level++;
  //   }
  // }
  // q_levels(n_levels-1) = arma::datum::inf;

  // return q_levels;

  /* Use matlab-generated levels when normpdf is not available */
  arma::vec q_levels;
  q_levels << -0.9740 << -0.6100 << -0.3420 << -0.1100
        << 0.1140 << 0.3460 << 0.6140 << 0.9780 << arma::datum::inf;

  return q_levels;
}
    
/* Can implement more complex classifier */
int HCDetector::classify(arma::vec featureVector) {
  /* Implement classification algorithm */
  if (featureVector(0) < sax_distance_decision && featureVector(1) > std_decision
      && featureVector(2) > skewness_decision) {
    return 1;
  }
  return 0;
}

/* Creates SAX distance matrix, from given quantization levels */
arma::mat HCDetector::create_sax_distance_mat(arma::vec q_levels) {
  int m = q_levels.n_rows;
  arma::mat distance_mat(m,m);
  
  /* Generate sax distance for each symbol pair */
  for (int i=0; i<m; i++) {
    for (int j=0; j<m; j++) {
      if (std::max(i,j) > 0) {
        distance_mat(i,j) = q_levels(std::max(i,j)-1) - q_levels(std::min(i,j));
      }
      if (abs(i-j) < 1) {
        distance_mat(i,j) = 0;
      }
    }
  }

  return distance_mat;
}

/* Calculates SAX distance between the two representations */
float HCDetector::sax_distance(arma::mat distance_matrix, std::string sax1, std::string sax2, int signal_len) {
  int w = sax1.size();
  float sax_distance_sum = 0;

  /* Sum all distances as found on the distance matrix */
  for (int i=0; i<w; i++) {
    sax_distance_sum += distance_matrix(sax1[i]-97, sax2[i]-97);
  }

  return sqrt((float)signal_len/w * sax_distance_sum); 
}

