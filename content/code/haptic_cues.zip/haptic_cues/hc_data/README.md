
All haptic-cues files consisting the knowledge db, are to be placed here. 

Same goes for the demo-simulation files f1200.dat and fProg.dat
