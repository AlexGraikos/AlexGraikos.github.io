#ifndef HCSEGMENTATOR_h
#define HCSEGMENTATOR_h


#include <vector>
#include <armadillo>

/* TODO: Add comparison slack to signal segmentation */

class HCSegmentator {
public:
	HCSegmentator();
	~HCSegmentator();

	arma::vec addSample(float sample);
private:
	int fit_step; // Segmentation modeling step
	int poly_order; // Model polynomial order
	float max_fit_error; // Max model-fit error
	int group_distance; // Min clustering distance
	int segment_size_limit; // To avoid creating huge signals and to detect cues in real time
  int comparison_slack; // Left-right signal segmentation slack;
	int current_sample; // Buffer sample counter (points to next sample index)
	int fit_start; // Polynomial fit start buffer index
	int fit_end; // Polynomial fit end buffer index
	int fitCounter; // Sample counter to initiate polynomial fit

	std::vector<float> signal_buffer;
	std::vector<int> previous_segment;

	arma::vec fitModel();
	arma::vec clusterSegment(int fit_end);
};

#endif