/**

This is a wrapper class for theHaptic Cue Recognition 
	involving the  HCDetector and HCSegmentator classes 
*/
#ifndef HAPTIC_CUES_H
#define HAPTIC_CUES_H


#include <HCSegmentator.h>
#include <HCDetector.h>
#include <string>
#include <armadillo>

class HapticCues{

private:
	HCSegmentator* segmentObject;
	HCDetector* detectObject;

public:
	HapticCues();
	~HapticCues();

	/* Just */
	int hapticDetection(float F_sample);

	std::string getDataDirPath() {return detectObject->DATA_DIR;};
};



#endif
