#ifndef HCDETECTOR_H
#define HCDETECTOR_H

#include <armadillo>
#include <string>

class HCDetector {
  public:
    HCDetector();
    ~HCDetector();

    int detectCue(arma::vec signal);
    
    arma::vec normalize(arma::vec signal);
    arma::vec interpolateBase(arma::vec base_signal, int force_signal_size);

    arma::mat dtw(arma::vec base, arma::vec signal, int width);
    arma::vec paa(arma::vec x);
    
    std::string sax(arma::vec paa_x, arma::vec q_levels);
    float sax_distance(arma::mat distance_matrix, std::string sax1, std::string sax2, int signal_len);

    int classify(arma::vec featureVector);
    
    arma::vec generate_sax_levels(int n_levels, int start, int finish, int points, float mu, float sigma);
    arma::mat create_sax_distance_mat(arma::vec q_levels); 

    /* Path of data and simulation files*/
    std::string DATA_DIR;
        
  private:
    arma::vec q_levels; // SAX quantization levels
    arma::mat sax_distance_mat; // SAX Distance matrix
    int paa_cuts; // Number of PAA partitions
    float dtw_delay_amount; // DTW max distortion between signals
    float sax_distance_decision; // SAX distance threshold
    float std_decision; // STD threshold  
    float skewness_decision; // Skewness threshold
    
    std::vector<arma::vec> knowledgeBase; // Knowledge Base signals
};

#endif
